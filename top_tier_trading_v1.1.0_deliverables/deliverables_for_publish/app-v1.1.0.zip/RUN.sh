#!/usr/bin/env bash
#
# RUN.sh – helper script to launch the Top_Tier_Trading stack on Unix systems.
#
# This script expects a `.env` or `conf/secrets.env` file to be present with all
# required environment variables.  It builds the containers (if necessary) and
# starts the services in detached mode.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Build and start the services
echo "[+] Building containers…"
docker compose -f docker/docker-compose.yml build

echo "[+] Starting services…"
docker compose -f docker/docker-compose.yml up -d

echo "[+] Services are starting.  Use 'docker compose ps' to view status."