#
# RUN.ps1 – helper script to launch the Top_Tier_Trading stack on Windows/PowerShell.
#
# Ensure that Docker Desktop is running and that a `conf\secrets.env` file exists
# with all required environment variables filled in.  This script builds and
# starts the containers.

$ErrorActionPreference = 'Stop'

Write-Host "[+] Building containers…"
docker compose -f docker/docker-compose.yml build

Write-Host "[+] Starting services…"
docker compose -f docker/docker-compose.yml up -d

Write-Host "[+] Services are starting.  Run `docker compose ps` to monitor status."