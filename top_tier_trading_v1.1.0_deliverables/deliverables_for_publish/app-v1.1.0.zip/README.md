# Top_Tier_Trading

This repository contains a simplified, multi‑service crypto‑trading platform used for demonstration and testing.  The platform comprises a TypeScript/Node.js API, a Next.js operations dashboard, Python worker services and a backtester.  Infrastructure definitions are provided for Docker Compose, Kubernetes and Terraform.

## Services

* **API service** – Exposes REST/GraphQL endpoints and server‑sent events for market data and risk metrics.  Located under `api/` and built with Node 18 and Express.  The Dockerfile compiles TypeScript sources and runs a slim runtime image.
* **Ops UI** – A Next.js 14 dashboard for operations teams.  Located under `ops-ui/`.  Includes authentication via NextAuth and a prototype backtesting page.
* **Workers** – Python services for market data ingestion, risk management and order execution.  Located under `workers/` and using `asyncio` and Redis.  Designed to scale horizontally.
* **Backtester** – Python service for simulating strategies against historical data.  Located under `backtester/`.

## Getting Started

1. **Clone the repository:**

   ```bash
   git clone https://github.com/tigantic/Top_Tier_Trading.git
   cd Top_Tier_Trading
   ```

2. **Create a secrets file:**  Copy `config/.env.example` to `conf/secrets.env` and fill in required environment variables (database credentials, API keys, etc.).  For production deployments, use a secrets manager instead of a file.

3. **Build and run locally:**  Use the provided `RUN.sh` (or `RUN.ps1` on Windows) to build and start all services:

   ```bash
   ./RUN.sh
   ```

   This will build the Docker images and start the containers defined in `docker/docker-compose.yml`.  Visit `http://localhost:3000` for the Ops UI and `http://localhost:8000` for the API.  Grafana is available on `http://localhost:3001` with default credentials `admin/admin`.

4. **Run tests:**  See `TEST_REPORT.md` for an overview of the test suites.  In short, run `npm test` in the `api/` and `ops-ui/` directories, and `poetry run pytest` in the `workers/` and `backtester/` directories.

## Documentation

* `BASELINE_SUMMARY.md` – Baseline analysis of the codebase, stack and deployment status.
* `CODE_HEALTH.md` – Repository health report with recommendations.
* `UPGRADE_AND_ROLLBACK.md` – Instructions for upgrading to v1.1.0 and rolling back if necessary.
* `RELEASE_NOTES.md` – Release notes for v1.1.0.

## License

This project is licensed under the MIT License.  See `LICENSE` for details.